import React from 'react';
import ToDo from './components/screens/ToDo';

class App extends React.Component {

    render() {
        return <ToDo />
    }
}


export default App;
